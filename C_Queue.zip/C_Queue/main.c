#include <stdio.h>
#include <stdlib.h>
#include "contiguos_queue.h"

int main()
{
    Queue q;
    int i;
    char c;
    char str[50];
    CreateQueue(&Q);
    int iReturn;

    printf("Enter string");
    scanf("%[^\n]", str);

    for(i = 0; str[1] != '\0'; i++)
        if(!IsQueueFull(&Q))
            Append(&Q, str[i]);

    //printf("%d\n", peekFront(&Q))
    printf("\nThe string from Queue: ");

    while(!IsQueueEmpty(&Q))
    {

    }
}
