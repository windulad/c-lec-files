#ifndef CONTIGUOS_QUEUE_H_INCLUDED
#define CONTIGUOS_QUEUE_H_INCLUDED

//Queue definition
#define MAXQUEUE 20
typedef int QueueElement;

typedef struct queue
{
    QueueElement items[MAXQUEUE];
    int front;
    int rear;
    int count;
}Queue;

//Create Queue
void CreateQueue(Queue *q)
{
    q -> count = 0;
    q -> front = 0;
    q -> rear = -1;
}

//Is Queue Empty?
#define TRUE 1
#define FALSE 0

int IsQueueEmpty(Queue *q)
{
    if(q -> rear < q -> front)
        return(TRUE);
    else
        return(FALSE);
}

//Is Queue Full?
int IsQueueFull(Queue *q)
{
    if(q -> rear == MAXQUEUE -1)
        return(TRUE);
    else
        return(FALSE);
}

//Append queue
void Append(Queue *q, QueueElement x)
{
    if(IsQueueFull(q)){
        printf("QueueFull\n");
        exit(1);
    }
    else{
        q -> items[++(q -> rear)] = x;
        q -> count++;
    }
}

//remove queue
void Serve(Queue *q, QueueElement *x)
{
    if(IsQueueEmpty(q)){
        printf("queue is empty, underflow\n");
        exit(1);
    }
    *x = q -> items[(q -> front)++];
    q -> count--;
}

int peekfront(Queue *q)
{
    if(IsQueueEmpty())
}

#endif // CONTIGUOS_QUEUE_H_INCLUDED
